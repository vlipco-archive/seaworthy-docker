#ifndef NGX_HTTP_REDIS2_HANDLER_H
#define NGX_HTTP_REDIS2_HANDLER_H


#include "ngx_http_redis2_module.h"

ngx_int_t ngx_http_redis2_handler(ngx_http_request_t *r);


#endif /* NGX_HTTP_REDIS2_HANDLER_H */

